package net.mcreator.fossilminecraft.client.model;

import net.minecraftforge.client.model.data.ModelData;

import net.minecraft.world.entity.Entity;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;

// Made with Blockbench 4.7.4
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports
public class ModelTrex extends EntityModel<Entity> {
	public final ModelPart leftLeg;
	public final ModelPart claw1_r1;
	public final ModelPart claw3_r1;
	public final ModelPart thigh_r1;
	public final ModelPart half_calve_r1;
	public final ModelPart calve_r1;
	public final ModelPart rightLeg;
	public final ModelPart claw1_r2;
	public final ModelPart claw3_r2;
	public final ModelPart thigh_r2;
	public final ModelPart half_calve_r2;
	public final ModelPart calve_r2;
	public final ModelPart body;
	public final ModelPart chest_r1;
	public final ModelPart Backandstomach_r1;
	public final ModelPart Head;
	public final ModelPart Flame2_r1;
	public final ModelPart Flame1_r1;
	public final ModelPart chest_r2;
	public final ModelPart leftArm;
	public final ModelPart forearm_r1;
	public final ModelPart rightArm;
	public final ModelPart forearm_r2;
	public final ModelPart tail;
	public final ModelPart tailsegment5_r1;

	public ModelTrex(ModelPart root) {
		this.leftLeg = root.getChild("leftLeg");
		this.rightLeg = root.getChild("rightLeg");
		this.body = root.getChild("body");
		this.Head = root.getChild("Head");
		this.leftArm = root.getChild("leftArm");
		this.rightArm = root.getChild("rightArm");
		this.tail = root.getChild("tail");
	}

	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData leftLeg = modelPartData.addChild("leftLeg",
				ModelPartBuilder.create().uv(-1, 56).cuboid(-1.0F, 8.5F, 3.0F, 2.0F, 0.5F, 2.0F, new Dilation(0.0F)).uv(8, 59).cuboid(1.0F, 8.505F,
						3.75F, 1.0F, 0.49F, 0.5F, new Dilation(0.0F)),
				ModelTransform.pivot(0.0F, 15.0F, -1.0F));
		ModelPartData claw1_r1 = leftLeg.addChild("claw1_r1",
				ModelPartBuilder.create().uv(8, 59).cuboid(-1.0F, -0.245F, -0.25F, 2.0F, 0.49F, 0.5F, new Dilation(0.0F)),
				ModelTransform.of(1.0F, 8.75F, 3.25F, 0.0F, 0.2618F, 0.0F));
		ModelPartData claw3_r1 = leftLeg.addChild("claw3_r1",
				ModelPartBuilder.create().uv(8, 59).cuboid(-1.0F, -0.245F, -0.25F, 2.0F, 0.49F, 0.5F, new Dilation(0.0F)),
				ModelTransform.of(1.0F, 8.75F, 4.75F, 0.0F, -0.2618F, 0.0F));
		ModelPartData thigh_r1 = leftLeg.addChild("thigh_r1",
				ModelPartBuilder.create().uv(41, 10).cuboid(-2.0F, -4.0F, -1.5F, 3.0F, 6.0F, 3.0F, new Dilation(0.0F)),
				ModelTransform.of(0.0F, 4.0F, 4.0F, 0.0F, 0.0F, -0.5236F));
		ModelPartData half_calve_r1 = leftLeg.addChild("half_calve_r1",
				ModelPartBuilder.create().uv(12, 27).cuboid(-1.0F, -2.25F, -1.125F, 2.0F, 4.0F, 2.25F, new Dilation(0.0F)),
				ModelTransform.of(0.0F, 6.5F, 4.0F, 0.0F, 0.0F, 0.829F));
		ModelPartData calve_r1 = leftLeg.addChild("calve_r1",
				ModelPartBuilder.create().uv(43, 27).cuboid(-1.75F, 0.0F, -0.55F, 2.0F, 1.0F, 2.1F, new Dilation(0.0F)),
				ModelTransform.of(0.5F, 7.5F, 3.5F, 0.0F, 0.0F, -0.2618F));
		ModelPartData rightLeg = modelPartData.addChild("rightLeg",
				ModelPartBuilder.create().uv(-1, 58).cuboid(-1.0F, 8.5F, -4.0F, 2.0F, 0.5F, 2.0F, new Dilation(0.0F)).uv(8, 59).cuboid(1.0F, 8.505F,
						-3.25F, 1.0F, 0.49F, 0.5F, new Dilation(0.0F)),
				ModelTransform.pivot(0.0F, 15.0F, 0.0F));
		ModelPartData claw1_r2 = rightLeg.addChild("claw1_r2",
				ModelPartBuilder.create().uv(8, 59).cuboid(-1.0F, -0.245F, -0.25F, 2.0F, 0.49F, 0.5F, new Dilation(0.0F)),
				ModelTransform.of(1.0F, 8.75F, -3.75F, 0.0F, 0.2618F, 0.0F));
		ModelPartData claw3_r2 = rightLeg.addChild("claw3_r2",
				ModelPartBuilder.create().uv(8, 59).cuboid(-1.0F, -0.245F, -0.25F, 2.0F, 0.49F, 0.5F, new Dilation(0.0F)),
				ModelTransform.of(1.0F, 8.75F, -2.25F, 0.0F, -0.2618F, 0.0F));
		ModelPartData thigh_r2 = rightLeg.addChild("thigh_r2",
				ModelPartBuilder.create().uv(42, 42).cuboid(-2.0F, -4.0F, -1.5F, 3.0F, 6.0F, 3.0F, new Dilation(0.0F)),
				ModelTransform.of(0.0F, 4.0F, -3.0F, 0.0F, 0.0F, -0.5236F));
		ModelPartData half_calve_r2 = rightLeg.addChild("half_calve_r2",
				ModelPartBuilder.create().uv(26, 45).cuboid(-1.0F, -2.25F, -1.125F, 2.0F, 4.0F, 2.25F, new Dilation(0.0F)),
				ModelTransform.of(0.0F, 6.5F, -3.0F, 0.0F, 0.0F, 0.829F));
		ModelPartData calve_r2 = rightLeg.addChild("calve_r2",
				ModelPartBuilder.create().uv(47, 0).cuboid(-1.75F, 0.0F, -0.55F, 2.0F, 1.0F, 2.1F, new Dilation(0.0F)),
				ModelTransform.of(0.5F, 7.5F, -3.5F, 0.0F, 0.0F, -0.2618F));
		ModelPartData body = modelPartData.addChild("body",
				ModelPartBuilder.create().uv(23, 0).cuboid(-7.0F, -17.0F, 0.0F, 12.0F, 5.0F, 0.0F, new Dilation(0.0F)),
				ModelTransform.pivot(0.0F, 24.0F, 0.0F));
		ModelPartData chest_r1 = body.addChild("chest_r1",
				ModelPartBuilder.create().uv(0, 27).cuboid(3.0F, -2.5F, -2.5F, 3.0F, 6.0F, 6.0F, new Dilation(0.0F)),
				ModelTransform.of(0.0F, -8.5F, 0.0F, -0.7854F, 0.0F, -0.1309F));
		ModelPartData Backandstomach_r1 = body.addChild("Backandstomach_r1",
				ModelPartBuilder.create().uv(0, 0).cuboid(-4.0F, -3.5F, -3.5F, 8.0F, 7.0F, 7.0F, new Dilation(0.0F)),
				ModelTransform.of(0.0F, -8.5F, 0.0F, -0.7854F, 0.0F, 0.0873F));
		ModelPartData Head = modelPartData.addChild("Head",
				ModelPartBuilder.create().uv(0, 14).cuboid(6.0F, -15.0F, -3.0F, 7.0F, 7.0F, 6.0F, new Dilation(0.0F)).uv(21, 22)
						.cuboid(13.0F, -13.0F, -2.5F, 6.0F, 3.0F, 5.0F, new Dilation(0.0F)).uv(47, 58)
						.cuboid(13.0F, -14.0F, -1.5F, 5.0F, 1.0F, 3.0F, new Dilation(0.0F)).uv(18, 30)
						.cuboid(11.0F, -9.0F, -2.0F, 7.0F, 1.0F, 4.0F, new Dilation(0.0F)).uv(30, 5)
						.cuboid(11.0F, -10.0F, -2.0F, 7.0F, 1.0F, 4.0F, new Dilation(0.0F)).uv(29, 4)
						.cuboid(11.0F, -10.0F, -2.5F, 8.0F, 1.0F, 5.0F, new Dilation(0.0F)),
				ModelTransform.pivot(0.0F, 24.0F, 0.0F));
		ModelPartData Flame2_r1 = Head.addChild("Flame2_r1",
				ModelPartBuilder.create().uv(38, 20).cuboid(-8.0F, -4.0F, 0.0F, 8.0F, 7.0F, 0.0F, new Dilation(0.0F)),
				ModelTransform.of(11.0F, -16.0F, 0.0F, 0.0F, 0.3491F, 0.0F));
		ModelPartData Flame1_r1 = Head.addChild("Flame1_r1",
				ModelPartBuilder.create().uv(40, 30).cuboid(-8.0F, -4.0F, 0.0F, 8.0F, 7.0F, 0.0F, new Dilation(0.0F)),
				ModelTransform.of(11.0F, -16.0F, 0.0F, 0.0F, -0.3491F, 0.0F));
		ModelPartData chest_r2 = Head.addChild("chest_r2",
				ModelPartBuilder.create().uv(13, 35).cuboid(-1.5F, -3.0F, -3.0F, 3.0F, 5.0F, 5.0F, new Dilation(0.0F)),
				ModelTransform.of(6.5367F, -8.6474F, 0.0F, -0.7854F, 0.0F, -0.4363F));
		ModelPartData leftArm = modelPartData.addChild("leftArm",
				ModelPartBuilder.create().uv(45, 37).cuboid(0.0F, -1.0F, -2.0F, 2.0F, 2.0F, 2.0F, new Dilation(0.0F)).uv(7, 58)
						.cuboid(2.5F, 2.0F, -2.0F, 0.5F, 1.0F, 0.75F, new Dilation(0.0F)).uv(7, 58)
						.cuboid(2.5F, 2.0F, -0.75F, 0.5F, 1.0F, 0.75F, new Dilation(0.0F)),
				ModelTransform.pivot(4.0F, 17.0F, 4.0F));
		ModelPartData forearm_r1 = leftArm.addChild("forearm_r1",
				ModelPartBuilder.create().uv(0, 14).cuboid(0.25F, -1.0F, -0.875F, 1.5F, 2.0F, 1.75F, new Dilation(0.0F)),
				ModelTransform.of(1.0F, 2.0F, -1.0F, 0.0F, 0.0F, -0.5236F));
		ModelPartData rightArm = modelPartData.addChild("rightArm",
				ModelPartBuilder.create().uv(34, 45).cuboid(0.0F, -1.0F, 0.0F, 2.0F, 2.0F, 2.0F, new Dilation(0.0F)).uv(7, 58)
						.cuboid(2.5F, 2.0F, 0.0F, 0.5F, 1.0F, 0.75F, new Dilation(0.0F)).uv(7, 58)
						.cuboid(2.5F, 2.0F, 1.25F, 0.5F, 1.0F, 0.75F, new Dilation(0.0F)),
				ModelTransform.pivot(4.0F, 17.0F, -4.0F));
		ModelPartData forearm_r2 = rightArm.addChild("forearm_r2",
				ModelPartBuilder.create().uv(0, 4).cuboid(0.25F, -1.0F, -0.875F, 1.5F, 2.0F, 1.75F, new Dilation(0.0F)),
				ModelTransform.of(1.0F, 2.0F, 1.0F, 0.0F, 0.0F, -0.5236F));
		ModelPartData tail = modelPartData.addChild("tail", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 24.0F, 0.0F));
		ModelPartData tailsegment5_r1 = tail.addChild("tailsegment5_r1",
				ModelPartBuilder.create().uv(23, 5).cuboid(-18.0F, -3.5F, -3.5F, 3.0F, 1.0F, 1.0F, new Dilation(0.0F)).uv(24, 35)
						.cuboid(-15.0F, -3.5F, -3.5F, 3.0F, 2.0F, 2.0F, new Dilation(0.0F)).uv(14, 45)
						.cuboid(-12.0F, -3.5F, -3.5F, 3.0F, 3.0F, 3.0F, new Dilation(0.0F)).uv(0, 41)
						.cuboid(-9.0F, -3.5F, -3.5F, 3.0F, 4.0F, 4.0F, new Dilation(0.0F)).uv(29, 35).cuboid(-6.0F, -3.5F, -3.5F, 3.0F, 5.0F, 5.0F,
								new Dilation(0.0F)),
				ModelTransform.of(0.0F, -8.5F, 0.0F, -0.7854F, 0.0F, 0.0F));
		return TexturedModelData.of(modelData, 64, 64);
	}

	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		leftLeg.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		rightLeg.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		body.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		Head.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		leftArm.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		rightArm.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		tail.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
	}
}
